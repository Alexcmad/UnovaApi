class LoginError(Exception):
    pass


class NotFoundError(Exception):
    pass
